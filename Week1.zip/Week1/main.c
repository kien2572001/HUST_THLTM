#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct Account {
    char name[50];
    char password[50];
    int status;
} Account;

typedef struct node {
    Account account;
    struct node *next;
} node;


void printMenu();
node *readFile(FILE *f);
void printList(node *head);
void saveToFile(node *head);

//Function 1
void registerAccount(node *head);
//Function 2
void activeAccount(node *head);
//Function 3
node *signinAccount(node *head);
//Function 4
void findAccountStatus(node *head);
//Function 5
void changePassword(node *head, node *currentAccount);
//Function 6
void singoutAccount(node *currentAccount);

int main() {
    int choice = 0;
    node *head = NULL;
    node *currentAccount = NULL;
    //Openfile
    FILE *fptr = fopen("account.txt", "r");
    if (fptr == NULL) {
        printf("Open file failed\n");
        exit(1);
    }
    //Read file
    head = readFile(fptr);
    fclose(fptr);
    printList(head);

    do {
        printMenu();
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                registerAccount(head);
                break;
            case 2:
                activeAccount(head);
                break;
            case 3:
                currentAccount = signinAccount(head);
                break;
            case 4:
                findAccountStatus(head);
                break;
            case 5:
                changePassword(head, currentAccount);
                break;
            case 6:
                singoutAccount(currentAccount);
                break;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }


    }while(choice != 6);
    return 0;
}

void printMenu(){
    printf("\nUSER MANAGER PROGRAM\n");
    printf("-------------------------------------\n");
    printf("1. Register\n");
    printf("2. Active\n");
    printf("3. Sign in\n");
    printf("4. Search\n");
    printf("5. Change password\n");
    printf("6. Sign out\n");
    printf("Your choice (1-6, other to quit): ");
}

node *readFile(FILE *f){
    node *head = NULL;
    node *current = NULL;
    node *newNode = NULL;
    char name[50];
    char password[50];
    int status;
    while (fscanf(f, "%s %s %d", name, password, &status) != EOF) {
        newNode = (node *) malloc(sizeof(node));
        strcpy(newNode->account.name, name);
        strcpy(newNode->account.password, password);
        newNode->account.status = status;
        newNode->next = NULL;
        if (head == NULL) {
            head = newNode;
            current = newNode;
        } else {
            current->next = newNode;
            current = newNode;
        }
    }
    return head;
}

void saveToFile(node *head){
    FILE *fptr = fopen("account.txt", "w");
    node *current = head;
    while (current != NULL) {
        fprintf(fptr, "%s %s %d\n", current->account.name, current->account.password, current->account.status);
        current = current->next;
    }
    fclose(fptr);
}

void printList(node *head){
    node *p = head;
    printf("List of accounts:\n");
    while (p != NULL) {
        printf("%s %s %d\n", p->account.name, p->account.password, p->account.status);
        p = p->next;
    }
    printf("\n");
}

void registerAccount(node *head){
    node *p = head;
    char name[50];
    char password[50];
    int status;
    printf("Username: ");
    scanf("%s", name);
    while (p != NULL) {
        if (strcmp(p->account.name, name) == 0) {
            printf("Account existed\n");
            return;
        }
        p = p->next;
    }
    printf("Password: ");
    scanf("%s", password);
    status = 2;
    
    node *newNode = (node *) malloc(sizeof(node));
    strcpy(newNode->account.name, name);
    strcpy(newNode->account.password, password);
    newNode->account.status = status;
    newNode->next = NULL;
    if (head == NULL) {
        head = newNode;
    } else {
        p = head;
        while (p->next != NULL) {
            p = p->next;
        }
        p->next = newNode;
    }
    saveToFile(head);
    printf("Successfully registration. Activation required\n");
}

void activeAccount(node *head){
    node *p = head;
    char name[50];
    char password[50];
    int status;
    printf("Username: ");
    scanf("%s", name);
    printf("Password: ");
    scanf("%s", password);

    node *temp = NULL;
    while (p != NULL) {
        if (strcmp(p->account.name, name) == 0) {
            if (strcmp(p->account.password, password) == 0) {
                temp = p;
            } else {
                printf("Password is incorrect\n");
                return;
            }
        }
        p = p->next;
    }

    if (temp == NULL) {
        printf("Account not existed\n");
        return;
    }

    if (temp->account.status == 1) {
        printf("Account is activated\n");
        return;
    }
    int count = 0;
    char code[50];
    do {
        printf("Code: ");
        scanf("%s", code);
        if (strcmp(code, "20194598") == 0) {
            temp->account.status = 1;
            saveToFile(head);
            printf("Successfully activated\n");
            return;
        }
        else{
            count++;
            printf("Activation code is incorrect\n");
        }
    } while (count < 4);
    printf("Account is blocked\n");
}

node *signinAccount(node *head){
    node *p = head;
    char name[50];
    char password[50];
    int status;
    printf("Username: ");
    scanf("%s", name);
    node *temp = NULL;
    while (p != NULL) {
        if (strcmp(p->account.name, name) == 0) {
            temp = p;
        }
        p = p->next;
    }
    if (temp == NULL) {
        printf("Cannot find account\n");
        return NULL;
    }
    if (temp->account.status == 0) {
        printf("Account is blocked\n");
        return NULL;
    }
    else if (temp->account.status == 2) {
        printf("Account is not activated\n");
        return NULL;
    }
    int count =0 ;
    do {
        printf("Password: ");
        scanf("%s", password);
        if (strcmp(password, temp->account.password) == 0) {
            printf("Hello %s\n", temp->account.name);
            return temp;
        }
        else{
            count++;
            printf("Password is incorrect\n");
        }
    } while (count < 4);
    printf("Account is blocked\n");
    temp->account.status = 0;
    saveToFile(head);
    return NULL;
}    
    

void findAccountStatus(node *head){
    node *p = head;
    char name[50];
    printf("Username: ");
    scanf("%s", name);
    while (p != NULL) {
        if (strcmp(p->account.name, name) == 0) {
            if (p->account.status == 0) {
                printf("Account is blocked\n");
                return;
            }
            else if (p->account.status == 1) {
                printf("Account is activate\n");
                return;
            }
            else if (p->account.status == 2) {
                printf("Account is not activate\n");
                return;
            }
        }
        p = p->next;
    }
    printf("Cannot find account\n");
}

void changePassword(node *head,node *currentAccount){
    if (currentAccount == NULL) {
        printf("Account is not sign in\n");
        return;
    }
    char password[50];
    printf("Password: ");
    scanf("%s", password);
    if (strcmp(password, currentAccount->account.password) == 0) {
        printf("New password: ");
        scanf("%s", password);
        strcpy(currentAccount->account.password, password);
        saveToFile(head);
        printf("Password is changed\n");
    }
    else{
        printf("Current password is incorrect. Please try again\n");
    }
    saveToFile(head);
}

void singoutAccount(node *currentAccount){
    if (currentAccount == NULL) {
        printf("Account is not sign in\n");
        return;
    }
    printf("Goodbye %s\n", currentAccount->account.name);
    currentAccount = NULL;
}